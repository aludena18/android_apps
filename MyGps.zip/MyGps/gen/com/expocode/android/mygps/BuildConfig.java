/** Automatically generated file. DO NOT MODIFY */
package com.expocode.android.mygps;

public final class BuildConfig {
    public final static boolean DEBUG = true;
}